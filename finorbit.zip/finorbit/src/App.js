// import React, { Component } from 'react';
import React from 'react';
import './App.css';
import Main from './Component/Main';
import { ToastContainer } from 'react-toastify';

function App() {
  return (
    <>
     <Main/>
     
    </>
  );
}

export default App;
